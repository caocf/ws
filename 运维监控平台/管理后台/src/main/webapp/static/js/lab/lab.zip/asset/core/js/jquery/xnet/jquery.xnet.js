;(function() {
(function($) {
if ($.xNet) {
	return;
}

/*
 * jQuery.xNet:  Wrap "jQuery.ajax" method with JSON response style.
 * @url:         Same explanation as "jQuery.ajax" method.
 * @type:        Optional. Same explanation as "jQuery.ajax" method.
 * @data:        Optional. Same explanation as "jQuery.ajax" method.
 * @traditional: Optional. Defaut value is "true". Same explanation as "jQuery.ajax" method.
 * @errorCodes:  Optional. Extended property, which used for list error codes you want to catching.
 *               Codes list will separate by comma, or use "*" as the wildcard.
 *               Example:
 *                 errorCodes: "2,3,4", or errorCodes: "*"
 * @success:     Optional. Callback for the Ajax response, when "code" value is "0".
 * @error:       Optional. Callback for the Ajax response, when "code" value other than "0".
 * @complete:    Optional. Same explanation as "jQuery.ajax" method.
 */
$.xNet = function(settings) {
	var defaults = {
		success: function() {}
	};
	settings = $.extend(defaults, settings);

	$.ajax({
		url: settings.url || window.location.href,
		type: settings.type || "get",
		data: settings.data,
		dataType: "json",
		traditional: (typeof settings.traditional == "boolean") ? settings.traditional : true,
		success: function(result) {
			if (result.code == 0) {
				settings.success(result);
			}
			else if (settings.errorCodes == "*") {
				settings.error(result);
			}
			else if (settings.errorCodes &&
					new RegExp("\\b" + result.code + "\\b", "i").test(settings.errorCodes + "")) {
				settings.error(result);
			}
			else {
				alert(result.msg);
			}
		},
		complete: settings.complete,
		error: function() {
			alert("HTTP Server error.");
		}
	});
}

})(jQuery);
})();